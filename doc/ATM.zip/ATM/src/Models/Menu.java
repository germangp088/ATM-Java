package Models;

public enum Menu {
	INGRESARACC,
    INGRESARNIP,
    MENU,
    SALDO,
    RETIRAR,
    DEPOSITAR,
    SALIR
}