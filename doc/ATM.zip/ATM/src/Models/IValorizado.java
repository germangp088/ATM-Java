package Models;

public interface IValorizado {
	int getValor();
	void setValor(int valor);
}
