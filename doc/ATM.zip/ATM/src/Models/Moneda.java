package Models;

public enum Moneda {
    PESO,
    DOLAR
}
